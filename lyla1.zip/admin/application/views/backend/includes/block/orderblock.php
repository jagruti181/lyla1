<section class="panel">

<div class="panel-body">
<ul class="nav nav-stacked">
<li><a href="<?php echo site_url('site/editorder?id=').$before['order']->id; ?>">User Details</a></li>
<li><a href="<?php echo site_url('site/editorderitems?id=').$before['order']->id; ?>">Order Items</a></li>
</ul>
</div>
</section>